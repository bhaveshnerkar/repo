import { Link } from "react-router-dom";
import { auth } from "../lib/firebase";
import { User } from "firebase/auth";
import { LogOut, Files, User as UserIcon } from "lucide-react";

interface NavbarProps {
  user: User | null;
  profile: any;
}

export default function Navbar({ user, profile }: NavbarProps) {
  return (
    <nav className="border-b border-black/10 px-6 py-4 flex items-center justify-between bg-white/50 backdrop-blur-md sticky top-0 z-50">
      <Link to="/" className="flex items-center gap-2">
        <div className="w-8 h-8 bg-black rounded-full flex items-center justify-center">
          <Files className="text-white w-4 h-4" />
        </div>
        <span className="font-serif italic text-2xl tracking-tight">DocFast</span>
      </Link>

      <div className="flex items-center gap-6">
        <Link to="/pricing" className="text-sm font-medium hover:text-black/60 transition-colors">Pricing</Link>
        {user ? (
          <div className="flex items-center gap-4">
            <Link 
              to="/dashboard" 
              className="px-4 py-2 bg-black text-white rounded-full text-sm font-medium hover:bg-black/80 transition-colors flex items-center gap-2"
            >
              <UserIcon className="w-4 h-4" />
              Dashboard
            </Link>
            <button 
              onClick={() => auth.signOut()}
              className="text-black/60 hover:text-black transition-colors"
              title="Logout"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        ) : (
          <Link 
            to="/auth" 
            className="px-6 py-2 bg-black text-white rounded-full text-sm font-medium hover:bg-black/80 transition-colors"
          >
            Get Started
          </Link>
        )}
      </div>
    </nav>
  );
}
