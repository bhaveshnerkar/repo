import { loadStripe } from "@stripe/stripe-js";

// Note: In a real app, this would be your Stripe Publishable Key
const stripePromise = loadStripe((import.meta as any).env.VITE_STRIPE_PUBLISHABLE_KEY || "pk_test_mock");

export default stripePromise;
