import { useState, useEffect, FormEvent } from "react";
import { User } from "firebase/auth";
import { db, handleFirestoreError, OperationType } from "../lib/firebase";
import { collection, query, where, onSnapshot, addDoc, serverTimestamp, getDocs, doc, updateDoc } from "firebase/firestore";
import { motion, AnimatePresence } from "motion/react";
import { useSearchParams } from "react-router-dom";
import { 
  Search, 
  MapPin, 
  Files, 
  Clock, 
  CheckCircle2, 
  Plus, 
  CloudUpload, 
  Smartphone,
  ExternalLink,
  ChevronRight,
  Shield,
  Zap,
  Star
} from "lucide-react";
import axios from "axios";
import stripePromise from "../lib/stripe-client";
import { Link } from "react-router-dom";
import { cn } from "../lib/utils";

interface DashboardProps {
  user: User;
  profile: any;
}

export default function Dashboard({ user, profile }: DashboardProps) {
  const isOwner = profile?.role === "cafe_owner";

  if (isOwner) {
    return <OwnerDashboard user={user} profile={profile} />;
  }

  return <UserDashboard user={user} profile={profile} />;
}

function UserDashboard({ user, profile }: DashboardProps) {
  const [searchParams, setSearchParams] = useSearchParams();
  const [owners, setOwners] = useState<any[]>([]);
  const [jobs, setJobs] = useState<any[]>([]);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [digiLockerLoading, setDigiLockerLoading] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [ownerFilter, setOwnerFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedJobForReceipt, setSelectedJobForReceipt] = useState<any>(null);
  const [selectedOwnerForServices, setSelectedOwnerForServices] = useState<any>(null);
  const [ownerServices, setOwnerServices] = useState<any[]>([]);

  useEffect(() => {
    if (selectedOwnerForServices) {
      const q = query(collection(db, "users", selectedOwnerForServices.id, "services"));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        setOwnerServices(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      });
      return () => unsubscribe();
    }
  }, [selectedOwnerForServices]);

  useEffect(() => {
    const success = searchParams.get("payment_success");
    if (success) {
      const handleSuccess = async () => {
        const q = query(collection(db, "jobs"), where("clientId", "==", user.uid), where("paymentStatus", "==", "unpaid"));
        const snap = await getDocs(q);
        if (!snap.empty) {
          const latestJob = snap.docs[0];
          await updateDoc(doc(db, "jobs", latestJob.id), {
            paymentStatus: "paid",
            status: "in_progress",
            updatedAt: serverTimestamp()
          });
          // Show receipt automatically for the newly paid job
          setSelectedJobForReceipt({ id: latestJob.id, ...latestJob.data(), paymentStatus: "paid" });
        }
        setSearchParams({});
      };
      handleSuccess();
    }
  }, [searchParams, user.uid, setSearchParams]);

  useEffect(() => {
    // Fetch Cafe Owners
    const fetchOwners = async () => {
      const q = query(collection(db, "users"), where("role", "==", "cafe_owner"));
      const snapshot = await getDocs(q);
      setOwners(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    };
    fetchOwners();

    // Listen to Jobs
    const qJobs = query(collection(db, "jobs"), where("clientId", "==", user.uid));
    const unsubscribeJobs = onSnapshot(qJobs, (snapshot) => {
      setJobs(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (err) => handleFirestoreError(err, OperationType.LIST, "jobs"));

    return () => {
      unsubscribeJobs();
    };
  }, [user.uid]);

  const initiateDigiLocker = () => {
    window.location.href = "/api/digilocker/auth";
  };

  const createJobFromService = async (service: any) => {
    try {
      const jobData = {
        clientId: user.uid,
        ownerId: selectedOwnerForServices.id,
        status: "pending",
        description: service.title,
        amount: service.totalPrice,
        serviceId: service.id,
        paymentStatus: "unpaid",
        createdAt: serverTimestamp(),
      };
      
      const docRef = await addDoc(collection(db, "jobs"), jobData);
      
      const response = await axios.post("/api/create-checkout-session", {
        jobId: docRef.id,
        amount: service.totalPrice,
        title: service.title,
      });

      const { sessionId } = response.data;
      const stripe = await stripePromise;
      if (stripe) {
        await (stripe as any).redirectToCheckout({ sessionId });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, "jobs");
    }
  };

  const filteredOwners = owners.filter(o => 
    o.displayName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    o.cafeDetails?.cafeName?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredJobs = jobs.filter(job => {
    const matchStatus = statusFilter === "all" || job.status === statusFilter;
    const matchOwner = ownerFilter === "all" || job.ownerId === ownerFilter;
    return matchStatus && matchOwner;
  });

  return (
    <div className="max-w-7xl mx-auto px-6 py-12 flex flex-col gap-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-serif italic mb-2 tracking-tight">Hey, {profile?.displayName?.split(' ')[0]}</h1>
          <p className="text-black/40 font-medium">Find a professional or upload documents via DigiLocker.</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setShowUploadModal(true)}
            className="px-6 py-4 bg-black text-white rounded-full font-medium flex items-center gap-2 hover:bg-black/80 transition-all"
          >
            <CloudUpload className="w-5 h-5" />
            Upload via DigiLocker
          </button>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-12">
        {/* Left Column - Shop Search */}
        <div className="lg:col-span-2 space-y-8">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-black/20" />
            <input 
              type="text" 
              placeholder="Search for cybercafes or services (e.g. Passport, PAN)..."
              className="w-full bg-white border border-black/5 rounded-2xl py-4 pl-12 pr-6 outline-none focus:border-black/20 transition-all font-medium"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="grid sm:grid-cols-2 gap-6">
            {filteredOwners.length > 0 ? filteredOwners.map(owner => (
              <motion.div 
                key={owner.id}
                whileHover={{ y: -4 }}
                className="bg-white border border-black/5 p-6 rounded-[24px] hover:shadow-xl hover:shadow-black/5 transition-all cursor-pointer group"
              >
                <div className="flex justify-between items-start mb-6">
                  <div className="w-12 h-12 bg-black/5 rounded-2xl flex items-center justify-center text-xl">
                    🏢
                  </div>
                  {owner.isVerified && (
                    <div className="px-3 py-1 bg-green-50 text-green-600 text-[10px] font-bold rounded-full uppercase tracking-widest flex items-center gap-1 border border-green-100/50">
                      <CheckCircle2 className="w-3 h-3" />
                      Verified
                    </div>
                  )}
                </div>
                <h3 className="text-xl font-bold mb-1">{owner.cafeDetails?.cafeName || owner.displayName}</h3>
                <p className="text-black/40 text-sm font-medium flex items-center gap-1 mb-4">
                  <MapPin className="w-3 h-3" />
                  {owner.cafeDetails?.location || "Remote Service"}
                </p>
                <div className="flex flex-wrap gap-2 mb-6">
                  {owner.cafeDetails?.services?.slice(0, 3).map((s: string) => (
                    <span key={s} className="px-2 py-1 bg-black/5 rounded-md text-[10px] font-bold uppercase tracking-wider text-black/60">
                      {s}
                    </span>
                  ))}
                </div>
                <button 
                  onClick={() => setSelectedOwnerForServices(owner)}
                  className="w-full py-3 bg-black/5 rounded-xl text-sm font-bold group-hover:bg-black group-hover:text-white transition-all flex items-center justify-center gap-2"
                >
                  View Services
                  <ChevronRight className="w-4 h-4" />
                </button>
              </motion.div>
            )) : (
              <div className="col-span-full py-20 text-center text-black/20 border-2 border-dashed border-black/5 rounded-[32px]">
                <Search className="w-12 h-12 mx-auto mb-4 opacity-20" />
                <p className="font-serif italic text-lg">No matches found for your search.</p>
              </div>
            )}
          </div>
        </div>

        {/* Right Column - Activity */}
        <div className="flex flex-col gap-8">
          <div className="bg-white border border-black/5 rounded-[32px] p-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-serif italic">Active Jobs</h2>
              <span className="px-3 py-1 bg-black/5 rounded-full text-[10px] font-bold">{filteredJobs.length}</span>
            </div>

            {/* Filters */}
            <div className="flex flex-col gap-3 mb-8">
              <div className="flex gap-2 p-1 bg-black/5 rounded-xl">
                {['all', 'pending', 'in_progress', 'completed'].map(s => (
                  <button 
                    key={s}
                    onClick={() => setStatusFilter(s)}
                    className={cn(
                      "flex-1 py-1.5 text-[10px] font-bold uppercase tracking-widest rounded-lg transition-all",
                      statusFilter === s ? "bg-white text-black shadow-sm" : "text-black/40 hover:text-black/60"
                    )}
                  >
                    {s.replace('_', ' ')}
                  </button>
                ))}
              </div>
              <select 
                value={ownerFilter}
                onChange={(e) => setOwnerFilter(e.target.value)}
                className="w-full bg-black/5 border border-transparent rounded-xl px-4 py-2.5 text-[10px] font-bold uppercase tracking-widest outline-none focus:border-black/10"
              >
                <option value="all">All Owners</option>
                {owners.map(o => <option key={o.id} value={o.id}>{o.cafeDetails?.cafeName || o.displayName}</option>)}
              </select>
            </div>

            <div className="space-y-6">
              {filteredJobs.length > 0 ? filteredJobs.map(job => (
                <div key={job.id} className="flex gap-4 group cursor-pointer">
                  <div className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0",
                    job.status === 'completed' ? "bg-green-50 text-green-500" : 
                    job.status === 'in_progress' ? "bg-yellow-50 text-yellow-500 animate-pulse" :
                    "bg-blue-50 text-blue-500"
                  )}>
                    {job.status === 'completed' ? <CheckCircle2 className="w-5 h-5" /> : 
                     job.status === 'in_progress' ? <Zap className="w-5 h-5" /> :
                     <Clock className="w-5 h-5" />}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-sm group-hover:underline">{job.description}</h4>
                    <div className="flex items-center justify-between">
                      <p className="text-xs text-black/40 font-medium">{job.status.replace('_', ' ')}</p>
                      <div className="flex items-center gap-2">
                        {job.paymentStatus === 'paid' && (
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedJobForReceipt(job);
                            }}
                            className="text-[10px] font-bold text-blue-600 hover:underline"
                          >
                            Receipt
                          </button>
                        )}
                        <span className={cn(
                          "text-[10px] font-bold px-2 py-0.5 rounded-full uppercase",
                          job.paymentStatus === 'paid' ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                        )}>
                          {job.paymentStatus}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )) : (
                <p className="text-black/20 font-serif italic">Your active jobs will appear here.</p>
              )}
            </div>
            <button className="w-full mt-8 py-4 border border-black/5 rounded-2xl text-xs font-bold uppercase tracking-widest text-black/40 hover:bg-black/5 hover:text-black transition-all">
              View All History
            </button>
          </div>

          <div className="bg-[#151619] rounded-[32px] p-8 text-white relative overflow-hidden">
            <motion.div 
              animate={{ rotate: 15 }}
              className="absolute -right-4 -top-4 w-32 h-32 bg-white/5 blur-3xl rounded-full"
            />
            <h3 className="text-xl font-serif italic mb-4">Secure Processing</h3>
            <p className="text-white/40 text-sm mb-6 leading-relaxed">
              Your documents are handled by verified professionals with bank-grade security and DigiLocker encryption.
            </p>
            <div className="flex items-center gap-2 text-green-400 font-bold text-[10px] uppercase tracking-widest">
              <Shield className="w-4 h-4" />
              Verified Escrow System
            </div>
          </div>
        </div>
      </div>

      {/* Services Selection Modal */}
      <AnimatePresence>
        {selectedOwnerForServices && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-6">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSelectedOwnerForServices(null)} className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative w-full max-w-2xl bg-white rounded-[40px] p-8 lg:p-12 shadow-2xl max-h-[80vh] overflow-y-auto">
              <div className="flex justify-between items-start mb-8">
                <div>
                  <h2 className="text-3xl font-serif italic mb-2">Available Services</h2>
                  <p className="text-black/40 font-medium">Offered by {selectedOwnerForServices.cafeDetails?.cafeName || selectedOwnerForServices.displayName}</p>
                </div>
                <button onClick={() => setSelectedOwnerForServices(null)} className="w-10 h-10 bg-black/5 rounded-full flex items-center justify-center hover:bg-black/10 transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                {ownerServices.length > 0 ? ownerServices.map(service => (
                  <div key={service.id} className="p-6 border border-black/5 rounded-3xl hover:border-black/20 transition-all">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex-1 mr-4">
                        <h4 className="font-bold text-lg mb-1">{service.title}</h4>
                        <p className="text-sm text-black/60 mb-2">{service.description}</p>
                        <div className="flex flex-wrap gap-2">
                          {service.requiredDocuments?.map((d: string) => (
                            <span key={d} className="px-2 py-0.5 bg-blue-50 text-blue-600 rounded text-[9px] font-bold uppercase">{d}</span>
                          ))}
                          {service.estimatedTime && (
                           <span className="px-2 py-0.5 bg-yellow-50 text-yellow-600 rounded text-[9px] font-bold uppercase flex items-center gap-1">
                             <Clock className="w-2.5 h-2.5" />
                             {service.estimatedTime}
                           </span>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-serif italic">₹ {service.totalPrice}</p>
                        <p className="text-[9px] font-bold text-black/20 uppercase tracking-widest">Inclusive of fees</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => createJobFromService(service)}
                      className="w-full py-3 bg-black text-white rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-black/80 transition-all"
                    >
                      Book This Service
                    </button>
                  </div>
                )) : (
                  <div className="text-center py-12 text-black/20 font-serif italic">
                    This owner hasn't listed specific services yet.
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* DigiLocker Modal */}
      <AnimatePresence>
        {showUploadModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 sm:p-12">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowUploadModal(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm" 
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-lg bg-white rounded-[40px] p-8 lg:p-12 shadow-2xl"
            >
              <div className="flex flex-col items-center text-center">
                <div className="w-20 h-20 bg-blue-50 text-blue-600 rounded-3xl flex items-center justify-center mb-8">
                  <Smartphone className="w-10 h-10" />
                </div>
                <h2 className="text-3xl font-serif italic mb-4">Link DigiLocker</h2>
                <p className="text-black/60 mb-8 font-medium">
                  Securely fetch your verified documents directly from your government-issued digital locker.
                </p>
                
                <div className="w-full space-y-4 mb-8">
                  <div className="p-4 bg-black/5 rounded-2xl flex items-center gap-4 text-left border border-black/5">
                    <Shield className="w-6 h-6 text-green-500" />
                    <div>
                      <p className="font-bold text-sm">Encrypted Connection</p>
                      <p className="text-xs text-black/40 font-medium">End-to-end secure transmission</p>
                    </div>
                  </div>
                </div>

                <button
                  onClick={initiateDigiLocker}
                  className="w-full py-5 bg-[#0052cc] text-white rounded-full font-bold flex items-center justify-center gap-3 hover:bg-[#0047b3] transition-all"
                >
                  Sign in with DigiLocker
                  <ExternalLink className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => setShowUploadModal(false)}
                  className="mt-4 text-black/40 text-sm font-bold uppercase tracking-widest hover:text-black transition-colors"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Receipt Modal */}
      <AnimatePresence>
        {selectedJobForReceipt && (
          <ReceiptModal 
            job={selectedJobForReceipt} 
            owner={owners.find(o => o.id === selectedJobForReceipt.ownerId)}
            onClose={() => setSelectedJobForReceipt(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}

import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { Download, Printer, X } from "lucide-react";

function ReceiptModal({ job, owner, onClose }: { job: any, owner: any, onClose: () => void }) {
  const downloadReceipt = async () => {
    const element = document.getElementById("receipt-content");
    if (!element) return;
    
    const canvas = await html2canvas(element);
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF();
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
    pdf.save(`DocFast_Receipt_${job.id}.pdf`);
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm" 
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-lg bg-white rounded-[40px] shadow-2xl overflow-hidden"
      >
        <div className="p-8 lg:p-12">
          {/* Scrollable content for the receipt */}
          <div id="receipt-content" className="bg-white border rounded-2xl p-8 text-black">
            <div className="flex justify-between items-start mb-8 pb-8 border-b">
              <div>
                <h2 className="text-2xl font-serif italic mb-1">DocFast</h2>
                <p className="text-[10px] font-bold text-black/40 uppercase tracking-widest">Payment Receipt</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] font-bold text-black/40 uppercase tracking-widest">Transaction ID</p>
                <p className="text-xs font-mono">{job.id}</p>
              </div>
            </div>

            <div className="space-y-6 mb-8">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-[10px] font-bold text-black/40 uppercase tracking-widest mb-1">Service</p>
                  <p className="text-sm font-medium">{job.description}</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-black/40 uppercase tracking-widest mb-1">Date</p>
                  <p className="text-sm font-medium">{job.createdAt?.toDate ? job.createdAt.toDate().toLocaleDateString() : 'Today'}</p>
                </div>
              </div>

              <div>
                <p className="text-[10px] font-bold text-black/40 uppercase tracking-widest mb-1">Provider</p>
                <p className="text-sm font-medium">{owner?.cafeDetails?.cafeName || owner?.displayName || "CyberCafe Owner"}</p>
                <p className="text-xs text-black/40">{owner?.cafeDetails?.location || "Remote Service"}</p>
              </div>
            </div>

            <div className="bg-black/5 rounded-xl p-4 space-y-2">
              <div className="flex justify-between text-xs font-medium">
                <span className="text-black/40">Amount Paid</span>
                <span>₹ {job.amount}.00</span>
              </div>
              <div className="flex justify-between text-xs font-medium">
                <span className="text-black/40">Platform Fee</span>
                <span>₹ 0.00</span>
              </div>
              <div className="pt-2 border-t flex justify-between font-bold text-green-600">
                <span>TOTAL</span>
                <span>₹ {job.amount}.00</span>
              </div>
            </div>

            <div className="mt-8 text-center">
              <p className="text-[10px] font-bold text-black/20 uppercase tracking-widest italic">Thank you for using DocFast</p>
            </div>
          </div>

          <div className="mt-8 grid grid-cols-2 gap-4">
            <button
              onClick={downloadReceipt}
              className="flex items-center justify-center gap-2 py-4 bg-black text-white rounded-full font-bold text-xs uppercase tracking-widest hover:bg-black/80 transition-all"
            >
              <Download className="w-4 h-4" />
              Download
            </button>
            <button
              onClick={() => window.print()}
              className="flex items-center justify-center gap-2 py-4 border border-black/10 rounded-full font-bold text-xs uppercase tracking-widest hover:bg-black/5 transition-all text-black"
            >
              <Printer className="w-4 h-4" />
              Print
            </button>
          </div>
          <button 
            onClick={onClose}
            className="absolute top-6 right-6 w-10 h-10 bg-black/5 rounded-full flex items-center justify-center hover:bg-black/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </motion.div>
    </div>
  );
}


function OwnerDashboard({ user, profile }: DashboardProps) {
  const [isSubmittingVerification, setIsSubmittingVerification] = useState(false);
  const [services, setServices] = useState<any[]>([]);
  const [showServiceForm, setShowServiceForm] = useState(false);
  const [editingService, setEditingService] = useState<any>(null);

  useEffect(() => {
    const q = query(collection(db, "users", user.uid, "services"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setServices(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsubscribe();
  }, [user.uid]);

  const requestVerification = async () => {
    setIsSubmittingVerification(true);
    try {
      await updateDoc(doc(db, "users", user.uid), {
        verificationStatus: "pending_review",
        updatedAt: serverTimestamp()
      });
      alert("Verification request submitted! Our team will review your documents.");
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, "users");
    } finally {
      setIsSubmittingVerification(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-4xl font-serif italic tracking-tight">Owner Console</h1>
            {profile?.isVerified ? (
              <div className="px-3 py-1 bg-green-50 text-green-600 text-[10px] font-bold rounded-full uppercase tracking-widest border border-green-100 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                verified partner
              </div>
            ) : profile?.verificationStatus === "pending_review" ? (
              <div className="px-3 py-1 bg-yellow-50 text-yellow-600 text-[10px] font-bold rounded-full uppercase tracking-widest border border-yellow-100">
                review in progress
              </div>
            ) : (
              <button 
                onClick={requestVerification}
                disabled={isSubmittingVerification}
                className="px-3 py-1 bg-red-50 text-red-600 text-[10px] font-bold rounded-full uppercase tracking-widest border border-red-100 hover:bg-red-100 transition-colors"
              >
                {isSubmittingVerification ? "submitting..." : "get verified"}
              </button>
            )}
          </div>
          <p className="text-black/40 font-medium">Manage incoming jobs and your cafe profile.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="text-[10px] font-bold uppercase tracking-wider text-black/40">Total Earnings</p>
            <p className="text-2xl font-serif italic text-black">₹ 12,450</p>
          </div>
          <div className="w-[1px] h-10 bg-black/10 mx-2" />
          <Link to="/pricing" className="px-6 py-4 bg-black text-white rounded-full font-bold text-xs uppercase tracking-widest hover:bg-black/80 transition-all">
            Manage Plan
          </Link>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3 space-y-8">
          {/* Subscription Status Card */}
          <div className="bg-white border border-black/5 rounded-[32px] p-8 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-6">
              <div className="w-16 h-16 bg-black text-white rounded-2xl flex items-center justify-center">
                <Star className="w-8 h-8 text-yellow-400" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-1">Current Plan: {profile?.subscriptionStatus === 'active' ? 'Pro' : 'Free'}</h3>
                <p className="text-black/40 text-sm font-medium">Your next billing date is May 26, 2026.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <Link to="/pricing" className="px-6 py-3 border border-black/10 rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-black/5 transition-all">
                Upgrade
              </Link>
              <button className="px-6 py-3 text-red-600 text-xs font-bold uppercase tracking-widest hover:underline">
                Cancel
              </button>
            </div>
          </div>

          {/* Manage Services Card */}
          <div className="bg-white border border-black/5 rounded-[32px] p-8">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-2xl font-serif italic mb-1">Your Services</h2>
                <p className="text-sm text-black/40 font-medium">Define your offerings and rates.</p>
              </div>
              <button 
                onClick={() => { setEditingService(null); setShowServiceForm(true); }}
                className="px-6 py-3 bg-black text-white rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-black/80 transition-all flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Add Service
              </button>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              {services.map(service => (
                <div key={service.id} className="p-6 border border-black/5 rounded-2xl group hover:border-black/20 transition-all">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="font-bold text-lg">{service.title}</h3>
                    <button 
                      onClick={() => { setEditingService(service); setShowServiceForm(true); }}
                      className="text-black/20 hover:text-black transition-colors"
                    >
                      <Plus className="w-4 h-4 rotate-45" />
                    </button>
                  </div>
                  <p className="text-sm text-black/60 mb-4 line-clamp-2">{service.description}</p>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs font-bold text-black/40 uppercase tracking-widest">Customer Pays</p>
                      <p className="text-xl font-serif italic">₹ {service.totalPrice}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs font-bold text-green-600 uppercase tracking-widest">You Earn</p>
                      <p className="text-sm font-bold">₹ {service.basePrice}</p>
                    </div>
                  </div>
                </div>
              ))}
              {services.length === 0 && (
                <div className="col-span-full py-12 text-center text-black/20 font-serif italic">
                  No services listed yet. Add your first service to start receiving jobs.
                </div>
              )}
            </div>
          </div>

          <div className="bg-white border border-black/5 rounded-[32px] p-8">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-serif italic">Pending Jobs</h2>
              <span className="px-3 py-1 bg-black/5 rounded-full text-[10px] font-bold">2 NEW</span>
            </div>
            
            <div className="space-y-4">
              <PendingJob 
                client="Bhavesh N."
                type="Birth Certificate Resizing"
                amount={150}
                time="10 mins ago"
              />
              <PendingJob 
                client="Rahul S."
                type="DigiLocker PAN Link"
                amount={200}
                time="1 hr ago"
              />
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-8">
            <div className="bg-[#151619] text-white rounded-[32px] p-8">
                <h3 className="text-xl font-serif italic mb-4">Availability</h3>
                <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                    <span className="text-sm font-medium">System Status</span>
                    <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                        <span className="text-xs font-bold text-green-400 uppercase">online</span>
                    </div>
                </div>
            </div>
            <div className="bg-white border border-black/5 rounded-[32px] p-8">
                <h3 className="text-xl font-serif italic mb-4">Reviews</h3>
                <p className="text-4xl font-serif mb-2">4.9 <span className="text-sm text-black/40 font-sans font-medium">/ 5.0</span></p>
                <div className="flex gap-1 mb-4">
                    {"★★★★★".split('').map((s,i) => <span key={i} className="text-yellow-400">{s}</span>)}
                </div>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-white border border-black/5 rounded-[32px] p-8">
              <h3 className="text-lg font-serif italic mb-6">Recent Activity</h3>
              <div className="space-y-6">
                <ActivityItem label="Payment Received" value="₹ 450" />
                <ActivityItem label="Job Completed" value="Passport Doc" />
                <ActivityItem label="Profile Updated" value="New Logo" />
              </div>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {showServiceForm && (
          <ServiceForm 
            user={user} 
            service={editingService} 
            onClose={() => setShowServiceForm(false)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}

import { Trash2 } from "lucide-react";

function ServiceForm({ user, service, onClose }: { user: User, service?: any, onClose: () => void }) {
  const [title, setTitle] = useState(service?.title || "");
  const [description, setDescription] = useState(service?.description || "");
  const [basePrice, setBasePrice] = useState(service?.basePrice || 0);
  const [requiredDocs, setRequiredDocs] = useState(service?.requiredDocuments?.join(', ') || "");
  const [estTime, setEstTime] = useState(service?.estimatedTime || "");
  const [loading, setLoading] = useState(false);

  const PLATFORM_FEE_PERCENT = 0.10;
  const platformFee = Math.round(basePrice * PLATFORM_FEE_PERCENT);
  const totalPrice = basePrice + platformFee;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = {
        ownerId: user.uid,
        title,
        description,
        basePrice: Number(basePrice),
        platformFee: Number(platformFee),
        totalPrice: Number(totalPrice),
        requiredDocuments: requiredDocs.split(',').map(s => s.trim()).filter(Boolean),
        estimatedTime: estTime,
        updatedAt: serverTimestamp(),
      };

      if (service) {
        await updateDoc(doc(db, "users", user.uid, "services", service.id), data);
      } else {
        await addDoc(collection(db, "users", user.uid, "services"), {
          ...data,
          createdAt: serverTimestamp(),
        });
      }
      onClose();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, "services");
    } finally {
      setLoading(false);
    }
  };

  const deleteService = async () => {
    if (!window.confirm("Are you sure?")) return;
    try {
      await updateDoc(doc(db, "users", user.uid, "services", service.id), {
        deleted: true // or use deleteDoc if you prefer
      });
      onClose();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, "services");
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative w-full max-w-lg bg-white rounded-[40px] p-8 lg:p-12 shadow-2xl">
        <h2 className="text-3xl font-serif italic mb-8">{service ? "Edit Service" : "Add Service"}</h2>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-xs font-bold uppercase tracking-widest text-black/40 mb-2">Service Title</label>
            <input 
              type="text" 
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-black/5 rounded-xl px-4 py-3 outline-none focus:bg-black/10 transition-colors font-medium"
              placeholder="e.g. Passport Photo Resizing"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-widest text-black/40 mb-2">Description</label>
            <textarea 
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-black/5 rounded-xl px-4 py-3 outline-none focus:bg-black/10 transition-colors font-medium h-24"
              placeholder="What exactly do you provide?"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-black/40 mb-2">Your Charge (₹)</label>
              <input 
                type="number" 
                required
                value={basePrice}
                onChange={(e) => setBasePrice(Number(e.target.value))}
                className="w-full bg-black/5 rounded-xl px-4 py-3 outline-none focus:bg-black/10 transition-colors font-medium"
              />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-black/40 mb-2">Final Price (₹)</label>
              <div className="w-full bg-black/10 rounded-xl px-4 py-3 font-bold text-black/60">
                {totalPrice}
                <span className="ml-2 text-[8px] font-bold text-black/20 uppercase tracking-widest block">Incl. ₹{platformFee} fee</span>
              </div>
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-widest text-black/40 mb-2">Required Docs (comma-separated)</label>
            <input 
              type="text" 
              value={requiredDocs}
              onChange={(e) => setRequiredDocs(e.target.value)}
              className="w-full bg-black/5 rounded-xl px-4 py-3 outline-none focus:bg-black/10 transition-colors font-medium"
              placeholder="PAN Card, ID, etc."
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-widest text-black/40 mb-2">Est. Time</label>
            <input 
              type="text" 
              value={estTime}
              onChange={(e) => setEstTime(e.target.value)}
              className="w-full bg-black/5 rounded-xl px-4 py-3 outline-none focus:bg-black/10 transition-colors font-medium"
              placeholder="e.g. 30 mins, 2 hours"
            />
          </div>

          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 py-4 bg-black text-white rounded-full font-bold text-xs uppercase tracking-widest hover:bg-black/80 transition-all"
            >
              {loading ? "Saving..." : "Save Service"}
            </button>
            {service && (
              <button
                type="button"
                onClick={deleteService}
                className="w-14 h-14 bg-red-50 text-red-600 rounded-full flex items-center justify-center hover:bg-red-100 transition-colors"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            )}
          </div>
        </form>
      </motion.div>
    </div>
  );
}

function PendingJob({ client, type, amount, time }: any) {
  return (
    <div className="p-6 border border-black/5 rounded-2xl flex items-center justify-between group hover:border-black/20 transition-all">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 bg-black/5 rounded-full flex items-center justify-center font-bold">
          {client[0]}
        </div>
        <div>
          <h4 className="font-bold">{type}</h4>
          <p className="text-xs text-black/40 font-medium">Client: {client} • {time}</p>
        </div>
      </div>
      <div className="text-right flex items-center gap-4">
        <div>
          <p className="text-sm font-bold text-green-600">₹ {amount}</p>
          <p className="text-[10px] font-bold text-black/20 uppercase">offer</p>
        </div>
        <button className="px-6 py-2 bg-black text-white rounded-full text-xs font-bold uppercase tracking-widest hover:bg-black/80 transition-all opacity-0 group-hover:opacity-100 translate-x-2 group-hover:translate-x-0">
          Accept
        </button>
      </div>
    </div>
  );
}

function ActivityItem({ label, value }: any) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-xs font-medium text-black/40">{label}</span>
      <span className="text-xs font-bold">{value}</span>
    </div>
  );
}
