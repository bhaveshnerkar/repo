import React from "react";
import { motion } from "motion/react";
import { Check, Shield, Zap, Star } from "lucide-react";
import { cn } from "../lib/utils";
import axios from "axios";
import stripePromise from "../lib/stripe-client";
import { auth, db } from "../lib/firebase";
import { doc, getDoc } from "firebase/firestore";
import { useEffect, useState } from "react";

export default function PricingPage() {
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProfile = async () => {
      const user = auth.currentUser;
      if (user) {
        const docSnap = await getDoc(doc(db, "users", user.uid));
        if (docSnap.exists()) {
          setProfile(docSnap.data());
        }
      }
      setLoading(false);
    };
    fetchProfile();
  }, []);

  const handleSubscribe = async (priceId: string) => {
    try {
      if (!profile) {
        window.location.href = "/auth";
        return;
      }

      if (profile.role !== "cafe_owner") {
        alert("Subscriptions are only available for CyberCafe Owners. Customers pay per individual job.");
        return;
      }

      const response = await axios.post("/api/create-subscription", {
        priceId,
        customerEmail: profile.email,
      });

      const { sessionId } = response.data;
      const stripe = await stripePromise;
      if (stripe) {
        await (stripe as any).redirectToCheckout({ sessionId });
      }
    } catch (error) {
      console.error("Subscription error:", error);
    }
  };

  const isOwner = profile?.role === "cafe_owner";

  return (
    <div className="max-w-7xl mx-auto px-6 py-20 lg:py-32">
      <div className="text-center mb-20">
        <h1 className="text-4xl lg:text-6xl font-serif italic mb-6 tracking-tight">Expert Plans <br /> <span className="text-black/30">For CyberCafe Owners</span></h1>
        <p className="text-black/60 max-w-xl mx-auto font-medium">
          Scale your document business with DocFast. Subscriptions are designed specifically for providers to manage high-volume jobs.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8 items-stretch">
        {/* Free Plan */}
        <PlanCard 
          title="Starter Owner"
          price="Free"
          description="Basic presence for local owners."
          features={[
            "Receive up to 5 job requests",
            "Individual work payouts",
            "Basic profile",
            "DigiLocker integration"
          ]}
          onClick={() => (window.location.href = "/dashboard")}
          cta={isOwner ? "Current Plan" : "Owner Only"}
          disabled={!isOwner}
        />

        {/* Pro Plan */}
        <PlanCard 
          title="Professional Provider"
          price="₹ 499"
          period="per month"
          description="For active shops and high-volume owners."
          highlighted
          features={[
            "Unlimited job requests",
            "Priority badge in search",
            "Advanced document tools",
            "Featured shop status",
            "0% Service Fees"
          ]}
          onClick={() => handleSubscribe("price_pro_mock")}
          cta={isOwner ? "Upgrade to Pro" : "Owner Upgrade Only"}
          icon={<Zap className="w-5 h-5" />}
          disabled={!isOwner}
        />

        {/* Business/Cafe Plan */}
        <PlanCard 
          title="Enterprise Network"
          price="₹ 1,499"
          period="per month"
          description="For multi-branch shops and agencies."
          features={[
            "Verified partner status",
            "Bulk processing API",
            "Dedicated account manager",
            "Custom branding",
            "White-label exports"
          ]}
          onClick={() => handleSubscribe("price_enterprise_mock")}
          cta={isOwner ? "Go Corporate" : "Owner Only"}
          icon={<Shield className="w-5 h-5" />}
          disabled={!isOwner}
        />
      </div>

      {/* Individual Payment Logic */}
      <div className="mt-32 max-w-4xl mx-auto bg-white border border-black/5 rounded-[40px] p-8 lg:p-16 flex flex-col lg:flex-row items-center gap-12">
        <div className="flex-1">
          <div className="w-16 h-16 bg-black rounded-3xl flex items-center justify-center mb-8">
            <Star className="text-yellow-400 w-8 h-8" />
          </div>
          <h2 className="text-3xl font-serif italic mb-6">Customer: Pay Per Job</h2>
          <p className="text-black/60 font-medium mb-8 leading-relaxed">
            Customers don't need a subscription. Just find a cafe owner and pay for exactly what you need. Secure, fast, and transparent.
          </p>
          <div className="space-y-4">
            <FeatureItem label="No Recurring Fees for Users" />
            <FeatureItem label="Secure Escrow per Job" />
            <FeatureItem label="Instant Document Delivery" />
          </div>
        </div>
        <div className="flex-1 w-full bg-[#151619] text-white p-8 rounded-[32px] font-mono text-sm space-y-4">
            <div className="flex justify-between border-b border-white/10 pb-2">
                <span className="opacity-40">Job ID</span>
                <span>DOC-88219</span>
            </div>
            <div className="flex justify-between border-b border-white/10 pb-2 text-green-400 font-bold">
                <span>TOTAL PAYABLE</span>
                <span>₹ 40.00</span>
            </div>
            <div className="pt-8">
                <button 
                  onClick={() => window.location.href = "/dashboard"}
                  className="w-full py-4 bg-white text-black rounded-xl font-bold uppercase tracking-widest text-xs"
                >
                    Back to Job Feed
                </button>
            </div>
        </div>
      </div>
    </div>
  );
}

interface PlanCardProps {
  title: string;
  price: string;
  period?: string;
  description: string;
  features: string[];
  cta: string;
  onClick: () => void;
  highlighted?: boolean;
  icon?: React.ReactNode;
  disabled?: boolean;
}

function PlanCard({ title, price, period, description, features, cta, onClick, highlighted, icon, disabled }: PlanCardProps) {
  return (
    <motion.div 
      whileHover={!disabled ? { y: -8 } : {}}
      className={cn(
        "flex flex-col p-8 lg:p-10 rounded-[40px] border transition-all",
        highlighted 
          ? "bg-[#151619] border-white/10 text-white shadow-2xl shadow-black/20 scale-105 z-10" 
          : "bg-white border-black/5 text-black",
        disabled && "opacity-50 grayscale cursor-not-allowed"
      )}
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-serif italic">{title}</h3>
        {icon}
      </div>
      <div className="mb-8">
        <div className="flex items-baseline gap-1">
          <span className="text-4xl lg:text-5xl font-serif font-black">{price}</span>
          {period && <span className={cn("text-sm font-medium", highlighted ? "text-white/40" : "text-black/40")}>{period}</span>}
        </div>
      </div>
      <p className={cn("text-sm mb-8 font-medium leading-relaxed", highlighted ? "text-white/60" : "text-black/60")}>
        {description}
      </p>
      
      <div className="flex-1 space-y-4 mb-10">
        {features.map(f => (
          <div key={f} className="flex items-center gap-3">
            <div className={cn("flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center", highlighted ? "bg-white/10" : "bg-black/5")}>
              <Check className={cn("w-3 h-3", highlighted ? "text-white" : "text-black")} />
            </div>
            <span className="text-sm font-medium">{f}</span>
          </div>
        ))}
      </div>

      <button
        onClick={onClick}
        disabled={disabled}
        className={cn(
          "w-full py-5 rounded-full font-bold text-xs uppercase tracking-widest transition-all",
          highlighted 
            ? "bg-white text-black hover:bg-white/90" 
            : "bg-black text-white hover:bg-black/80 shadow-lg shadow-black/10",
          disabled && "bg-gray-200 text-gray-500 hover:bg-gray-200"
        )}
      >
        {cta}
      </button>
    </motion.div>
  );
}

function FeatureItem({ label }: { label: string }) {
    return (
        <div className="flex items-center gap-3">
            <Check className="w-5 h-5 text-green-500" />
            <span className="font-bold text-sm">{label}</span>
        </div>
    )
}
