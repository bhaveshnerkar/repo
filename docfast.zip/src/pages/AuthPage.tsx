import { useState } from "react";
import { auth, db } from "../lib/firebase";
import { signInWithPopup, GoogleAuthProvider } from "firebase/auth";
import { doc, setDoc, getDoc, serverTimestamp } from "firebase/firestore";
import { useSearchParams, useNavigate } from "react-router-dom";
import { motion } from "motion/react";
import { Shield, Files, Check } from "lucide-react";
import { cn } from "../lib/utils";

export default function AuthPage() {
  const [searchParams] = useSearchParams();
  const initialRole = searchParams.get("role") === "cafe_owner" ? "cafe_owner" : "user";
  const [role, setRole] = useState<"user" | "cafe_owner">(initialRole);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      
      const user = result.user;
      const userRef = doc(db, "users", user.uid);
      const userSnap = await getDoc(userRef);

      if (!userSnap.exists()) {
        await setDoc(userRef, {
          userId: user.uid,
          email: user.email,
          displayName: user.displayName,
          photoURL: user.photoURL,
          role: role,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
          isVerified: false,
          subscriptionStatus: "inactive",
        });
      }

      navigate("/dashboard");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-72px)] flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md bg-white border border-black/5 rounded-[32px] p-8 lg:p-12 shadow-xl shadow-black/5"
      >
        <div className="flex flex-col items-center text-center mb-10">
          <div className="w-16 h-16 bg-black rounded-full flex items-center justify-center mb-6">
            <Files className="text-white w-8 h-8" />
          </div>
          <h1 className="text-3xl font-serif italic mb-2">Welcome to DocFast</h1>
          <p className="text-black/60 font-medium">Join the network for faster document processing.</p>
        </div>

        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4 p-1 bg-black/5 rounded-2xl">
            <RoleButton 
              active={role === "user"} 
              onClick={() => setRole("user")}
              label="I need docs"
            />
            <RoleButton 
              active={role === "cafe_owner"} 
              onClick={() => setRole("cafe_owner")}
              label="I'm a provider"
            />
          </div>

          {error && (
            <div className="p-4 bg-red-50 border border-red-100 text-red-600 text-sm rounded-2xl font-medium">
              {error}
            </div>
          )}

          <button
            onClick={handleGoogleLogin}
            disabled={loading}
            className="w-full flex items-center justify-center gap-3 px-8 py-4 bg-white border border-black/10 rounded-full font-medium hover:bg-black/5 transition-all text-black disabled:opacity-50"
          >
            <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
            {loading ? "Authenticating..." : "Continue with Google"}
          </button>

          <p className="text-xs text-center text-black/40 px-4">
            By continuing, you agree to DocFast's <a href="#" className="underline">Terms of Service</a> and <a href="#" className="underline">Privacy Policy</a>.
          </p>
        </div>
      </motion.div>
    </div>
  );
}

function RoleButton({ active, onClick, label }: { active: boolean, onClick: () => void, label: string }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "py-3 px-4 rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-2",
        active ? "bg-white shadow-sm text-black" : "text-black/40 hover:text-black/60"
      )}
    >
      {active && <Check className="w-4 h-4" />}
      {label}
    </button>
  );
}
