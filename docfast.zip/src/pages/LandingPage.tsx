import React from "react";
import { motion } from "motion/react";
import { Link } from "react-router-dom";
import { ArrowRight, Shield, Zap, CloudUpload, Clock, CheckCircle } from "lucide-react";

export default function LandingPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="px-6 py-20 lg:py-32 flex flex-col items-center text-center max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <span className="px-3 py-1 bg-black/5 rounded-full text-xs font-semibold uppercase tracking-wider mb-6 inline-block">
            Revolutionizing Document Processing
          </span>
          <h1 className="text-5xl lg:text-8xl font-serif leading-[0.9] tracking-tight mb-8">
            Fast, Secure <br /> 
            <span className="italic">Document Hub</span>
          </h1>
          <p className="text-lg lg:text-xl text-black/60 max-w-2xl mx-auto mb-10 font-medium">
            Connect with certified cybercafe owners for all your document needs. 
            Seamless DigiLocker integration for instant secure uploads.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/auth"
              className="w-full sm:w-auto px-8 py-4 bg-black text-white rounded-full font-medium hover:bg-black/80 transition-all flex items-center justify-center gap-2 group"
            >
              Start Your First Job
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link
              to="/pricing"
              className="w-full sm:w-auto px-8 py-4 border border-black/10 rounded-full font-medium hover:bg-black/5 transition-all"
            >
              View Pricing
            </Link>
          </div>
        </motion.div>
      </section>

      {/* Features Grid */}
      <section className="bg-white border-y border-black/5 py-24">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-3 gap-12">
          <FeatureCard 
            icon={<Zap className="w-6 h-6" />}
            title="Rapid Turnaround"
            description="Our network of cafe owners ensures your documents are processed within minutes, not days."
          />
          <FeatureCard 
            icon={<Shield className="w-6 h-6" />}
            title="DigiLocker Linked"
            description="Fetch authenticated documents directly from DigiLocker. Zero risk, absolute security."
          />
          <FeatureCard 
            icon={<CloudUpload className="w-6 h-6" />}
            title="Easy Uploads"
            description="Drag, drop, or pull from cloud. We handle all formats and resizing requirements."
          />
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="bg-[#151619] rounded-[32px] p-8 lg:p-16 text-white flex flex-col lg:flex-row items-center gap-12">
          <div className="flex-1">
            <h2 className="text-3xl lg:text-5xl font-serif italic mb-6">Are you a CyberCafe Owner?</h2>
            <p className="text-white/60 text-lg mb-8">
              Join DocFast and grow your business. Get direct access to clients needing document help,
              manage payments easily, and build your reputation.
            </p>
            <Link
              to="/auth?role=cafe_owner"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white text-black rounded-full font-medium hover:bg-white/90 transition-all"
            >
              Become a Provider
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="flex-1 grid grid-cols-2 gap-4 w-full">
            <StatsBadge icon={<CheckCircle className="w-4 h-4 text-green-400" />} label="Verified Owners" />
            <StatsBadge icon={<Clock className="w-4 h-4 text-blue-400" />} label="24/7 Support" />
            <StatsBadge icon={<Zap className="w-4 h-4 text-yellow-400" />} label="Instant Payouts" />
            <StatsBadge icon={<Shield className="w-4 h-4 text-purple-400" />} label="Secure Storage" />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-black/5 text-center text-sm text-black/40">
        <p>© 2026 DocFast. All rights reserved.</p>
        <div className="mt-4 flex items-center justify-center gap-6">
          <a href="#" className="hover:text-black transition-colors">Terms</a>
          <a href="#" className="hover:text-black transition-colors">Privacy</a>
          <a href="#" className="hover:text-black transition-colors">Legal</a>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="flex flex-col gap-4">
      <div className="w-12 h-12 bg-black text-white rounded-2xl flex items-center justify-center">
        {icon}
      </div>
      <h3 className="text-xl font-bold">{title}</h3>
      <p className="text-black/60 leading-relaxed font-medium">
        {description}
      </p>
    </div>
  );
}

function StatsBadge({ icon, label }: { icon: React.ReactNode, label: string }) {
  return (
    <div className="bg-white/5 border border-white/10 rounded-2xl p-4 flex items-center gap-3">
      {icon}
      <span className="text-sm font-medium">{label}</span>
    </div>
  );
}
