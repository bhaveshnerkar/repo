import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import Stripe from "stripe";
import dotenv from "dotenv";
import helmet from "helmet";
import { rateLimit } from "express-rate-limit";
import axios from "axios";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Security Middleware
  app.use(helmet({
    contentSecurityPolicy: false, // For development and iframe compatibility
  }));

  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, 
    max: 100, 
    standardHeaders: true,
    legacyHeaders: false,
  });
  app.use("/api/", limiter);

  // Initialize Stripe
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "sk_test_mock", {
    apiVersion: "2025-01-27-preview",
  } as any);

  app.use(express.json());

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // DigiLocker Logic
  const DIGILOCKER_CLIENT_ID = process.env.DIGILOCKER_CLIENT_ID;
  const DIGILOCKER_CLIENT_SECRET = process.env.DIGILOCKER_CLIENT_SECRET;
  const REDIRECT_URI = `${process.env.APP_URL}/api/digilocker/callback`;

  app.get("/api/digilocker/auth", (req, res) => {
    const authUrl = `https://accounts.digitallocker.gov.in/public/oauth2/1/authorize?response_type=code&client_id=${DIGILOCKER_CLIENT_ID}&redirect_uri=${REDIRECT_URI}&state=xyz`;
    res.redirect(authUrl);
  });

  app.get("/api/digilocker/callback", async (req, res) => {
    const { code } = req.query;
    try {
      // In a real scenario, exchange code for tokens
      // const response = await axios.post("https://accounts.digitallocker.gov.in/public/oauth2/1/token", {
      //   code,
      //   client_id: DIGILOCKER_CLIENT_ID,
      //   client_secret: DIGILOCKER_CLIENT_SECRET,
      //   redirect_uri: REDIRECT_URI,
      //   grant_type: "authorization_code",
      // });
      // const { access_token } = response.data;
      
      // Redirect back to dashboard with success
      res.redirect("/dashboard?digilocker_success=true");
    } catch (error) {
      console.error("DigiLocker Callback Error:", error);
      res.redirect("/dashboard?digilocker_error=access_denied");
    }
  });

  // Stripe Checkout Session for Subscription
  app.post("/api/create-subscription", async (req, res) => {
    try {
      const { priceId, customerEmail } = req.body;
      const session = await stripe.checkout.sessions.create({
        mode: "subscription",
        payment_method_types: ["card"],
        line_items: [
          {
            price: priceId,
            quantity: 1,
          },
        ],
        success_url: `${process.env.APP_URL}/dashboard?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${process.env.APP_URL}/pricing`,
        customer_email: customerEmail,
      });
      res.json({ sessionId: session.id });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Stripe Checkout Session for Individual Job
  app.post("/api/create-checkout-session", async (req, res) => {
    try {
      const { jobId, amount, title } = req.body;
      const session = await stripe.checkout.sessions.create({
        mode: "payment",
        payment_method_types: ["card"],
        line_items: [
          {
            price_data: {
              currency: "inr",
              product_data: {
                name: `Job: ${title}`,
                description: `Payment for job ${jobId}`,
              },
              unit_amount: amount * 100, // In paise
            },
            quantity: 1,
          },
        ],
        success_url: `${process.env.APP_URL}/dashboard?job_id={CHECKOUT_SESSION_ID}&payment_success=true`,
        cancel_url: `${process.env.APP_URL}/dashboard?payment_cancelled=true`,
        metadata: { jobId },
      });
      res.json({ sessionId: session.id });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
